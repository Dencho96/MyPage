$(document).ready(function() {
    $('#fullpage').fullpage({
        sectionSelector: '.page-section',
        autoScrolling: true,
        scrollBar: true
    });
 
});

new Typewriter('#hero__title', {
    strings: 'Welcome to my page !',
    autoStart: true,
    delay: 'natural'
});

new WOW().init();